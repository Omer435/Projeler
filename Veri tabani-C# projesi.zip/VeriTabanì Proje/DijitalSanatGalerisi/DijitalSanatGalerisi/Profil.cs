﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DijitalSanatGalerisi
{
    public partial class Profil : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=9658");
        public Profil()
        {
            InitializeComponent();
        }

        private void btnFotoYukle_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Resim Dosyaları|*.jpg;*.jpeg;*.png;";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string dosyaAdi = Path.GetFileName(ofd.FileName);
                string hedefKlasor = Path.Combine(Application.StartupPath, "uploads", "profiles");
                Directory.CreateDirectory(hedefKlasor);

                string hedefYol = Path.Combine(hedefKlasor, dosyaAdi);
                File.Copy(ofd.FileName, hedefYol, true);

                string veritabaniYolu = $"uploads/profiles/{dosyaAdi}";

                using (var conn = new NpgsqlConnection("server=localhost; port=5432; Database=digitalGallery; user ID=postgres; password=9658"))
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand("UPDATE artist SET profile_image = @img WHERE artist_id = @id", conn);
                    cmd.Parameters.AddWithValue("@img", veritabaniYolu);
                    cmd.Parameters.AddWithValue("@id", kullaniciBilgileri.artist_id);
                    cmd.ExecuteNonQuery();
                }

                kullaniciBilgileri.profile_image = veritabaniYolu;
                picProfile.ImageLocation = veritabaniYolu;
                MessageBox.Show("Fotoğraf güncellendi!");
            }
        }

        private void Profil_Load(object sender, EventArgs e)
        {
            txtProfilAd.Text = kullaniciBilgileri.fname;
            txtProfilSoyad.Text = kullaniciBilgileri.lname;
            txtProfilKullaniciAdi.Text = kullaniciBilgileri.username;
            txtProfilEposta.Text = kullaniciBilgileri.email;
            picProfile.ImageLocation = kullaniciBilgileri.profile_image;
        }

        private void YukleProfil()
        {
            txtProfilAd.Text = kullaniciBilgileri.fname;
            txtProfilSoyad.Text = kullaniciBilgileri.lname;
            txtProfilKullaniciAdi.Text = kullaniciBilgileri.username;
            txtProfilEposta.Text = kullaniciBilgileri.email;
            picProfile.ImageLocation = kullaniciBilgileri.profile_image;
        }

        private void btnDuzenle_Click(object sender, EventArgs e)
        {
            btnDuzenle.Enabled = false;
            btnGuncelle.Enabled = true;
            txtProfilAd.ReadOnly = false;
            txtProfilSoyad.ReadOnly = false;
            txtProfilKullaniciAdi.ReadOnly = false;
            txtProfilEposta.ReadOnly = false;
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtProfilAd.Text.Length >= 3 && txtProfilSoyad.Text.Length >= 2 && txtProfilKullaniciAdi.Text.Length > 5 && txtProfilEposta.Text.Length > 5)
            {
                baglanti.Open();
                var cmd = new NpgsqlCommand("UPDATE artist SET fname = @fname, lname = @lname, username = @username, email = @mail WHERE artist_id = @id", baglanti);
                cmd.Parameters.AddWithValue("@fname", txtProfilAd.Text);
                cmd.Parameters.AddWithValue("@lname", txtProfilSoyad.Text);
                cmd.Parameters.AddWithValue("@username", txtProfilKullaniciAdi.Text);
                cmd.Parameters.AddWithValue("@mail", txtProfilEposta.Text);
                cmd.Parameters.AddWithValue("@id", kullaniciBilgileri.artist_id);
                cmd.ExecuteNonQuery();
                kullaniciBilgileri.fname = txtProfilAd.Text;
                kullaniciBilgileri.lname = txtProfilSoyad.Text;
                kullaniciBilgileri.username = txtProfilKullaniciAdi.Text;
                kullaniciBilgileri.email = txtProfilEposta.Text;
                YukleProfil();
                btnDuzenle.Enabled = true;
                btnGuncelle.Enabled = false;
                txtProfilAd.ReadOnly = true;
                txtProfilSoyad.ReadOnly = true;
                txtProfilKullaniciAdi.ReadOnly = true;
                txtProfilEposta.ReadOnly = true;
                baglanti.Close();
                MessageBox.Show("Bilgileriniz Başarıyla Güncellendi");
            }
            else
            {
                MessageBox.Show("Bir şeyler yanlış");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AnaSayfa anaSayfa = new AnaSayfa();
            anaSayfa.Show();
            this.Close();
            
        }

        private void logOutBtn_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void gonderilerimBtn_Click(object sender, EventArgs e)
        {
            Gonderilerim gonderilerim = new Gonderilerim();
            this.Close();
            gonderilerim.Show();
        }
    }
}
