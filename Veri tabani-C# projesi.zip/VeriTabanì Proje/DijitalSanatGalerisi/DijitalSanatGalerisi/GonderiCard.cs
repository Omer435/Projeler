﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace DijitalSanatGalerisi
{
    public partial class GonderiCard : UserControl
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=9658");

        private int artworkid;
        private int currentUserId = kullaniciBilgileri.artist_id;
        
        public GonderiCard(int _artworkid)
        {
            InitializeComponent();
            artworkid = _artworkid;
            YukleGonderi();
            YukleYorumlar();
        }

        private void YukleGonderi()
        {
            int gsid=-1;
            baglanti.Open();
            string artistPhotoPath = "";
            using (var cmd3 = new NpgsqlCommand("SELECT a.profile_image FROM artist a JOIN artwork ar ON a.artist_id=ar.artist_id WHERE artwork_id = @id", baglanti))
            {
                cmd3.Parameters.AddWithValue("@id", artworkid);
                var result = cmd3.ExecuteScalar();
                artistPhotoPath = result.ToString();
                gonderiProfilPictureBox.ImageLocation = artistPhotoPath;
            }

            var cmd = new NpgsqlCommand(@"
            SELECT a.title, a.description, a.image_path, a.upload_date,
                       ar.fname || ' ' || ar.lname AS artist_name,
                       (SELECT COUNT(*) FROM likes WHERE artworkid = a.artwork_id) AS like_count,
                       (SELECT COUNT(*) FROM favorites WHERE artworkid = a.artwork_id) AS favorite_count,
                       EXISTS (SELECT 1 FROM likes WHERE artworkid = a.artwork_id AND artistid = @userid) AS liked,
                       EXISTS (SELECT 1 FROM favorites WHERE artworkid = a.artwork_id AND artistid = @userid) AS favorited, a.artist_id
                FROM artwork a
                JOIN artist ar ON a.artist_id = ar.artist_id
                WHERE a.artwork_id = @id", baglanti);

            cmd.Parameters.AddWithValue("@id", artworkid);
            cmd.Parameters.AddWithValue("@userid", currentUserId);

            using (var reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    baslikLbl.Text = reader.GetString(0);
                    aciklamaLbl.Text = reader.GetString(1);
                    string imagePath = reader.GetString(2);
                    using (var fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                    {
                        pictureBoxFoto.Image = Image.FromStream(fs);
                    }
                    artitsAdiLbl.Text = reader.GetString(4);
                    begeniSayiLbl.Text = reader.GetInt32(5).ToString();
                    favoriSayiLbl.Text = reader.GetInt32(6).ToString();
                    uploadDateLbl.Text = reader.GetFieldValue<DateTimeOffset>(3).ToString("dd MMM yyyy");
                    gsid = Convert.ToInt32(reader["artist_id"]);
                    begenBtn.Text = reader.GetBoolean(7) ? "Beğeni Kaldır" : "Beğen";
                    if (reader.GetBoolean(7) == true)
                    {
                        begenBtn.BackColor = Color.MediumVioletRed;
                    }
                    else
                    {
                        begenBtn.BackColor = SystemColors.Control;
                    }
                    favoriBtn.Text = reader.GetBoolean(8) ? "Favoriden Çıkar" : "Favorile";
                    if (reader.GetBoolean(8) == true)
                    {
                        favoriBtn.BackColor = Color.LightGoldenrodYellow;
                    }
                    else
                    {
                        favoriBtn.BackColor = SystemColors.Control;
                    }
                }
            }
            gonderiSilBtn.Visible = (gsid == currentUserId);
            baglanti.Close();
        }

        private void YukleYorumlar()
        {
            baglanti.Open();

            var cmd = new NpgsqlCommand(@"
            SELECT c.commentid, ar.username, c.content, c.artistid, ar.profile_image
                FROM comments c
                JOIN artist ar ON c.artistid = ar.artist_id
                WHERE c.artworkid = @id
                ORDER BY c.createdat DESC", baglanti);
            cmd.Parameters.AddWithValue("@id", artworkid);

            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int commentId = reader.GetInt32(0);
                    string user = reader.GetString(1);
                    string comment = reader.GetString(2);
                    int ownerId = reader.GetInt32(3);
                    string imageLoc = reader.GetString(4);
                    var panel = new Panel { Width = 320, Height = 40 };
                    var pbox = new PictureBox { Width = 30, Height = 30, SizeMode=PictureBoxSizeMode.StretchImage ,ImageLocation=imageLoc};
                    var label = new Label { Text = $"{user}: {comment}", AutoSize = true, Left=35, Top=5};
                    panel.Controls.Add(pbox);
                    panel.Controls.Add(label);

                    yorumlarFLP.Controls.Add(panel);
                }
            }
            baglanti.Close();
        }

        private void YorumSil(int commentId)
        {
            yorumlarFLP.Controls.Clear();
            baglanti.Open();         
            var cmd2 = new NpgsqlCommand("DELETE FROM comments WHERE commentid = @id AND artistid = @userid", baglanti);
            cmd2.Parameters.AddWithValue("@id", commentId);
            cmd2.Parameters.AddWithValue("@userid", currentUserId);
            cmd2.ExecuteNonQuery();
            baglanti.Close();
            YukleYorumlar();
            YukleGonderi();
        }

        private void begenBtn_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            var check = new NpgsqlCommand("SELECT 1 FROM likes WHERE artworkid = @aid AND artistid = @uid", baglanti);
            check.Parameters.AddWithValue("@aid", artworkid);
            check.Parameters.AddWithValue("@uid", currentUserId);
            var exists = check.ExecuteScalar() != null;

            var cmd = exists ?
                new NpgsqlCommand("DELETE FROM likes WHERE artworkid = @aid AND artistid = @uid", baglanti) :
                new NpgsqlCommand("INSERT INTO likes (artworkid, artistid) VALUES (@aid, @uid)", baglanti);

            cmd.Parameters.AddWithValue("@aid", artworkid);
            cmd.Parameters.AddWithValue("@uid", currentUserId);
            cmd.ExecuteNonQuery();

            baglanti.Close();
            YukleGonderi();            
        }

        private void favoriBtn_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            var check = new NpgsqlCommand("SELECT 1 FROM favorites WHERE artworkid = @aid AND artistid = @uid", baglanti);
            check.Parameters.AddWithValue("@aid", artworkid);
            check.Parameters.AddWithValue("@uid", currentUserId);
            var exists = check.ExecuteScalar() != null;

            var cmd = exists ?
                new NpgsqlCommand("DELETE FROM favorites WHERE artworkid = @aid AND artistid = @uid", baglanti) :
                new NpgsqlCommand("INSERT INTO favorites (artworkid, artistid) VALUES (@aid, @uid)", baglanti);

            cmd.Parameters.AddWithValue("@aid", artworkid);
            cmd.Parameters.AddWithValue("@uid", currentUserId);
            cmd.ExecuteNonQuery();

            baglanti.Close();
            YukleGonderi();    
        }

        private void gonderBtn_Click(object sender, EventArgs e)
        {
            yorumlarFLP.Controls.Clear();
            baglanti.Open();
            var cmd = new NpgsqlCommand("INSERT INTO comments (artworkid, artistid, content) VALUES (@aid, @uid, @content)", baglanti);
            cmd.Parameters.AddWithValue("@aid", artworkid);
            cmd.Parameters.AddWithValue("@uid", currentUserId);
            cmd.Parameters.AddWithValue("@content", yorumTxtBox.Text);
            cmd.ExecuteNonQuery();

            yorumTxtBox.Clear();
            baglanti.Close();
            YukleYorumlar();        
        }



        private void GonderiCard_Load(object sender, EventArgs e)
        {

        }

        private void gonderiSilBtn_Click(object sender, EventArgs e)
        {
            var onay = MessageBox.Show("Bu gönderiyi silmek istediğinize emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (onay == DialogResult.Yes)
            {
                baglanti.Open();
                var cmd = new NpgsqlCommand("DELETE FROM artwork WHERE artwork_id = @id AND artist_id = @userid", baglanti);
                cmd.Parameters.AddWithValue("@id", artworkid);
                cmd.Parameters.AddWithValue("@userid", currentUserId);
                cmd.ExecuteNonQuery();
                baglanti.Close();

                MessageBox.Show("Gönderi silindi.");
                
                if (this.ParentForm is AnaSayfa anaForm)
                {
                    anaForm.flowRefresh();
                }
                if (this.ParentForm is Gonderilerim gonderilerim)
                {
                    gonderilerim.YükleKendiGonderilerim();
                }

            }
        }
    }
}
