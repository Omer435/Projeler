﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DijitalSanatGalerisi
{
    public partial class GonderiEkle : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=9658");

        public GonderiEkle()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        string selectedImagePath = "";
        private void dosyaSecBtn_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    selectedImagePath = ofd.FileName;
                    onizlemePictureBox.Image = Image.FromFile(selectedImagePath);
                }
            }
        }

        private void gonderiYukleBtn_Click(object sender, EventArgs e)
        {
            string category = catCombo.SelectedItem?.ToString() ?? "";
            if (string.IsNullOrEmpty(category) || !(category == "Tarih" || category == "Manzara" || category == "Bilgi" || category == "Eğlence"))
            {
                MessageBox.Show("Lütfen geçerli bir kategori seçiniz: Tarih, Manzara, Bilgi veya Eğlence.");
                return;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(titleTxt.Text) || string.IsNullOrWhiteSpace(selectedImagePath))
                {
                    MessageBox.Show("Başlık ve resim seçimi zorunludur.");
                    return;
                }

                string title = titleTxt.Text.Trim();
                string description = descTxt.Text.Trim();

                string imagePathInProject = Path.Combine("uploads", Path.GetFileName(selectedImagePath));

                string fullDestinationPath = Path.Combine(Application.StartupPath, imagePathInProject);
                Directory.CreateDirectory(Path.GetDirectoryName(fullDestinationPath));
                File.Copy(selectedImagePath, fullDestinationPath, true);

                baglanti.Open();
                var cmd = new NpgsqlCommand(@"INSERT INTO artwork (title, description, category, image_path, upload_date, artist_id)VALUES (@title, @desc, @cat, @img, NOW(), @aid)", baglanti);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@desc", description);
                cmd.Parameters.AddWithValue("@cat", category);
                cmd.Parameters.AddWithValue("@img", imagePathInProject);
                cmd.Parameters.AddWithValue("@aid", kullaniciBilgileri.artist_id);

                cmd.ExecuteNonQuery();

                baglanti.Close();

                MessageBox.Show("Gönderi başarıyla yüklendi!");
                AnaSayfa anaSayfa = new AnaSayfa();
                anaSayfa.Show();
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AnaSayfa anaSayfa = new AnaSayfa();
            this.Close();
            anaSayfa.Show();
        }
    }
}
