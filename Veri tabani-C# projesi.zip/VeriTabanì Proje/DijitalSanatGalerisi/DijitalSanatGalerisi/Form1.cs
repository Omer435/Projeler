﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DijitalSanatGalerisi
{
    public partial class girisEkrani : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=9658");
        public girisEkrani()
        {
            InitializeComponent();
        }

        private void baslangicEkrani_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            kayitEkrani kayitEkrani = new kayitEkrani();
            this.Hide();
            kayitEkrani.ShowDialog();
            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            string query = "SELECT * FROM public.artist WHERE username=@username AND password=@password";

            using (NpgsqlCommand cmd = new NpgsqlCommand(query, baglanti))
            {
                cmd.Parameters.AddWithValue("@username", usernameTxt.Text);
                cmd.Parameters.AddWithValue("@password", passwordTxt.Text);

                try
                {
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            kullaniciBilgileri.artist_id = reader.GetInt32(reader.GetOrdinal("artist_id"));
                            kullaniciBilgileri.fname = reader.GetString(reader.GetOrdinal("fname"));
                            kullaniciBilgileri.lname = reader.GetString(reader.GetOrdinal("lname"));
                            kullaniciBilgileri.email = reader.GetString(reader.GetOrdinal("email"));
                            kullaniciBilgileri.username = reader.GetString(reader.GetOrdinal("username"));
                            kullaniciBilgileri.password = reader.GetString(reader.GetOrdinal("password"));
                            kullaniciBilgileri.profile_image = reader.GetString(reader.GetOrdinal("profile_image"));

                            AnaSayfa anaSayfa = new AnaSayfa();
                            this.Hide();
                            anaSayfa.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Kullanıcı adı veya şifre yanlış!");
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Bir şeyler yanlış!");
                }
            }

            baglanti.Close();
            
        
                
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
    
}   
