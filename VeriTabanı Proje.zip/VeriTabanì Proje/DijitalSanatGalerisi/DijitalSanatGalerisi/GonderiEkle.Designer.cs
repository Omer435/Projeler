﻿namespace DijitalSanatGalerisi
{
    partial class GonderiEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.titleTxt = new System.Windows.Forms.TextBox();
            this.descTxt = new System.Windows.Forms.TextBox();
            this.catCombo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.onizlemePictureBox = new System.Windows.Forms.PictureBox();
            this.dosyaSecBtn = new System.Windows.Forms.Button();
            this.gonderiYukleBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.onizlemePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(718, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 35);
            this.button3.TabIndex = 10;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Gönderi Ekle";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Başlık:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(100, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Açıklama:";
            // 
            // titleTxt
            // 
            this.titleTxt.Location = new System.Drawing.Point(159, 182);
            this.titleTxt.MaxLength = 15;
            this.titleTxt.Name = "titleTxt";
            this.titleTxt.Size = new System.Drawing.Size(100, 20);
            this.titleTxt.TabIndex = 14;
            // 
            // descTxt
            // 
            this.descTxt.Location = new System.Drawing.Point(159, 223);
            this.descTxt.MaxLength = 105;
            this.descTxt.Name = "descTxt";
            this.descTxt.Size = new System.Drawing.Size(100, 20);
            this.descTxt.TabIndex = 15;
            // 
            // catCombo
            // 
            this.catCombo.FormattingEnabled = true;
            this.catCombo.Items.AddRange(new object[] {
            "Tarih",
            "Manzara",
            "Bilgi",
            "Eğlence"});
            this.catCombo.Location = new System.Drawing.Point(159, 260);
            this.catCombo.Name = "catCombo";
            this.catCombo.Size = new System.Drawing.Size(100, 21);
            this.catCombo.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(104, 263);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Kategori:";
            // 
            // onizlemePictureBox
            // 
            this.onizlemePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onizlemePictureBox.Location = new System.Drawing.Point(287, 123);
            this.onizlemePictureBox.Name = "onizlemePictureBox";
            this.onizlemePictureBox.Size = new System.Drawing.Size(200, 200);
            this.onizlemePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.onizlemePictureBox.TabIndex = 18;
            this.onizlemePictureBox.TabStop = false;
            // 
            // dosyaSecBtn
            // 
            this.dosyaSecBtn.Location = new System.Drawing.Point(335, 329);
            this.dosyaSecBtn.Name = "dosyaSecBtn";
            this.dosyaSecBtn.Size = new System.Drawing.Size(100, 23);
            this.dosyaSecBtn.TabIndex = 19;
            this.dosyaSecBtn.Text = "Dosya Seç";
            this.dosyaSecBtn.UseVisualStyleBackColor = true;
            this.dosyaSecBtn.Click += new System.EventHandler(this.dosyaSecBtn_Click);
            // 
            // gonderiYukleBtn
            // 
            this.gonderiYukleBtn.Location = new System.Drawing.Point(528, 204);
            this.gonderiYukleBtn.Name = "gonderiYukleBtn";
            this.gonderiYukleBtn.Size = new System.Drawing.Size(98, 39);
            this.gonderiYukleBtn.TabIndex = 20;
            this.gonderiYukleBtn.Text = "Yükle";
            this.gonderiYukleBtn.UseVisualStyleBackColor = true;
            this.gonderiYukleBtn.Click += new System.EventHandler(this.gonderiYukleBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(677, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 35);
            this.button1.TabIndex = 21;
            this.button1.Text = "<";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // GonderiEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 532);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gonderiYukleBtn);
            this.Controls.Add(this.dosyaSecBtn);
            this.Controls.Add(this.onizlemePictureBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.catCombo);
            this.Controls.Add(this.descTxt);
            this.Controls.Add(this.titleTxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GonderiEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gonderi Ekle";
            ((System.ComponentModel.ISupportInitialize)(this.onizlemePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox titleTxt;
        private System.Windows.Forms.TextBox descTxt;
        private System.Windows.Forms.ComboBox catCombo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox onizlemePictureBox;
        private System.Windows.Forms.Button dosyaSecBtn;
        private System.Windows.Forms.Button gonderiYukleBtn;
        private System.Windows.Forms.Button button1;
    }
}