﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DijitalSanatGalerisi.AnaSayfa;

namespace DijitalSanatGalerisi
{
    public partial class Gonderilerim : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=1234");
        public Gonderilerim()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Profil profil = new Profil();
            this.Close();
            profil.Show();
        }
        private int currentUserId = kullaniciBilgileri.artist_id;

        private void Gonderilerim_Load(object sender, EventArgs e)
        {
            YükleKendiGonderilerim();
        }
        public void YükleKendiGonderilerim()
        {
            flowLayoutPanelGonderilerim.Controls.Clear();

            try
            {
                baglanti.Open();
                var cmd = new NpgsqlCommand("SELECT artwork_id FROM artwork WHERE artist_id = @id ORDER BY upload_date DESC", baglanti);
                cmd.Parameters.AddWithValue("@id", currentUserId);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        var gonderiCard = new GonderiCard(id);
                        flowLayoutPanelGonderilerim.Controls.Add(gonderiCard);
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Gönderiler yüklenirken hata oluştu");
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Artwork> GetArtworksByCategory(int artistId, string kategori)
        {
            var artworks = new List<Artwork>();
            baglanti.Open();

            var query = "SELECT * FROM get_my_artworks_by_category(@artistId, @kategori)";

            using (var cmd = new NpgsqlCommand(query, baglanti))
            {
                cmd.Parameters.AddWithValue("@artistId", artistId);
                cmd.Parameters.AddWithValue("@kategori", kategori);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        artworks.Add(new Artwork
                        {
                            artwork_id = reader.GetInt32(0),
                            title = reader.GetString(1),
                            description = reader.GetString(2),
                            image_path = reader.GetString(3),
                            upload_date = reader.GetDateTime(4)
                        });
                    }
                }
            }

            baglanti.Close();
            return artworks;
        }

        private void filtreleMyBtn_Click(object sender, EventArgs e)
        {
            int artistId = currentUserId;
            string kategori = kategoriMyCmbBox.Text.Trim();

            var liste = GetArtworksByCategory(artistId, kategori);

            flowLayoutPanelGonderilerim.Controls.Clear();
            foreach (var art in liste)
            {
                GonderiCard card = new GonderiCard(art.artwork_id);
                flowLayoutPanelGonderilerim.Controls.Add(card);
            }
        }

        public List<Artwork> GetArtworksByMinLikes(int artistId, int minLikes)
        {
            var artworks = new List<Artwork>();
            baglanti.Open();

            var query = "SELECT * FROM get_my_artworks_by_min_likes(@artistId, @minLikes)";

            using (var cmd = new NpgsqlCommand(query, baglanti))
            {
                cmd.Parameters.AddWithValue("@artistId", artistId);
                cmd.Parameters.AddWithValue("@minLikes", minLikes);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        artworks.Add(new Artwork
                        {
                            artwork_id = reader.GetInt32(0),
                            title = reader.GetString(1),
                            description = reader.GetString(2),
                            image_path = reader.GetString(3),
                            upload_date = reader.GetDateTime(4)
                        });
                    }
                }
            }

            baglanti.Close();
            return artworks;
        }

        private void BtnMySirala_Click(object sender, EventArgs e)
        {
            int artistId = currentUserId;
            int minLikes = int.TryParse(txtMyLikeSayisi.Text, out int val) ? val : 0;

            var liste = GetArtworksByMinLikes(artistId, minLikes);

            flowLayoutPanelGonderilerim.Controls.Clear();
            foreach (var art in liste)
            {
                GonderiCard card = new GonderiCard(art.artwork_id);
                flowLayoutPanelGonderilerim.Controls.Add(card);
            }
        }
    }
}
