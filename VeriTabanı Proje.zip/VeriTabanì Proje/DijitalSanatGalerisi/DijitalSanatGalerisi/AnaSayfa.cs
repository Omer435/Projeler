﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DijitalSanatGalerisi
{
    public partial class AnaSayfa : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=1234");

        public AnaSayfa()
        {
            InitializeComponent();
        }

        private void AnaSayfa_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            var cmd = new NpgsqlCommand("select * from get_artwork_id", baglanti);
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int id = reader.GetInt32(0);
                    GonderiCard card = new GonderiCard(id);
                    flowGallery.Controls.Add(card);
                }
            }
            baglanti.Close();

        }

        public void flowRefresh()
        {
            flowGallery.Controls.Clear();
            baglanti.Open();
            var cmd = new NpgsqlCommand("SELECT artwork_id FROM artwork ORDER BY upload_date DESC", baglanti);
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int id = reader.GetInt32(0);
                    GonderiCard card = new GonderiCard(id);
                    flowGallery.Controls.Add(card);
                }
            }
            baglanti.Close();
        }



        private void profilBtn_Click(object sender, EventArgs e)
        {
            Profil profil = new Profil();
            profil.Show();
            this.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public class Artwork
        {
            public int artwork_id { get; set; }
            public string title { get; set; }
            public string description { get; set; }
            public string image_path { get; set; }
            public DateTimeOffset upload_date { get; set; }
            public string artist_name { get; set; }
        }

        public List<Artwork> GetFilteredArtworks(string kategori, string sanatci)
        {
            var artworks = new List<Artwork>();
            baglanti.Open();

            var query = @"
            SELECT a.artwork_id, a.title, a.description, a.image_path, a.upload_date,
               ar.fname || ' ' || ar.lname AS artist_name
            FROM artwork a
            JOIN artist ar ON a.artist_id = ar.artist_id
            WHERE (LOWER(a.category) LIKE LOWER(@kategori) OR @kategori = '')
            AND (LOWER(ar.fname || ' ' || ar.lname) LIKE LOWER(@sanatci) OR @sanatci = '')
            ORDER BY a.upload_date DESC";

            using (var cmd = new NpgsqlCommand(query, baglanti))
            {
                cmd.Parameters.AddWithValue("@kategori", string.IsNullOrEmpty(kategori) ? "" : "%" + kategori + "%");
                cmd.Parameters.AddWithValue("@sanatci", string.IsNullOrEmpty(sanatci) ? "" : "%" + sanatci + "%");

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        artworks.Add(new Artwork
                        {
                            artwork_id = reader.GetInt32(0),
                            title = reader.GetString(1),
                            description = reader.IsDBNull(2) ? "" : reader.GetString(2),
                            image_path = reader.GetString(3),
                            upload_date = reader.GetFieldValue<DateTimeOffset>(4),
                            artist_name = reader.GetString(5),
                        });
                    }
                }
            }

            baglanti.Close();
            return artworks;
        }

        private void filtreleBtn_Click(object sender, EventArgs e)
        {
            string seciliKategori = kategoriCmbBox.SelectedItem?.ToString() ?? "";
            string sanatciAdi = sanatciTxt.Text.Trim();

            var filtreliListe = GetFilteredArtworks(seciliKategori, sanatciAdi);

            flowGallery.Controls.Clear();
            foreach (var art in filtreliListe)
            {
                GonderiCard card = new GonderiCard(art.artwork_id);
                flowGallery.Controls.Add(card);
            }

        }

        private void gndrYukleBtn_Click(object sender, EventArgs e)
        {
            GonderiEkle gonderiEkle = new GonderiEkle();
            this.Close();
            gonderiEkle.Show();
        }
        public List<int> GetArtworkIdsByLikeCount(int minLikes)
        {
            var artworkIds = new List<int>();
            baglanti.Open();

            string query = "SELECT * FROM get_filtered_likes_artworks(@minLikes)";
            using (var cmd = new NpgsqlCommand(query, baglanti))
            {
                cmd.Parameters.AddWithValue("@minLikes", minLikes);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        artworkIds.Add(reader.GetInt32(0));
                    }
                }
            }

            baglanti.Close();
            return artworkIds;
        }
        private void BtnSirala_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtLikeSayisi.Text.Trim(), out int minLikes))
            {
                MessageBox.Show("Geçerli bir sayı gir!");
                return;
            }

            var idListesi = GetArtworkIdsByLikeCount(minLikes);

            flowGallery.Controls.Clear();

            foreach (int id in idListesi)
            {
                GonderiCard card = new GonderiCard(id);
                flowGallery.Controls.Add(card);
            }
        }
    }
}
