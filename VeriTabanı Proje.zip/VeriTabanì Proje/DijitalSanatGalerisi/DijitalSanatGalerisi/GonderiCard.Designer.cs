﻿namespace DijitalSanatGalerisi
{
    partial class GonderiCard
    {
        /// <summary> 
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Bileşen Tasarımcısı üretimi kod

        /// <summary> 
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxFoto = new System.Windows.Forms.PictureBox();
            this.artitsAdiLbl = new System.Windows.Forms.Label();
            this.baslikLbl = new System.Windows.Forms.Label();
            this.aciklamaLbl = new System.Windows.Forms.Label();
            this.yorumlarFLP = new System.Windows.Forms.FlowLayoutPanel();
            this.begenBtn = new System.Windows.Forms.Button();
            this.favoriBtn = new System.Windows.Forms.Button();
            this.yorumTxtBox = new System.Windows.Forms.TextBox();
            this.gonderBtn = new System.Windows.Forms.Button();
            this.begeniSayiLbl = new System.Windows.Forms.Label();
            this.favoriSayiLbl = new System.Windows.Forms.Label();
            this.gonderiProfilPictureBox = new System.Windows.Forms.PictureBox();
            this.uploadDateLbl = new System.Windows.Forms.Label();
            this.gonderiSilBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFoto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gonderiProfilPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxFoto
            // 
            this.pictureBoxFoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxFoto.Location = new System.Drawing.Point(37, 61);
            this.pictureBoxFoto.MaximumSize = new System.Drawing.Size(250, 191);
            this.pictureBoxFoto.MinimumSize = new System.Drawing.Size(250, 191);
            this.pictureBoxFoto.Name = "pictureBoxFoto";
            this.pictureBoxFoto.Size = new System.Drawing.Size(250, 191);
            this.pictureBoxFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxFoto.TabIndex = 0;
            this.pictureBoxFoto.TabStop = false;
            // 
            // artitsAdiLbl
            // 
            this.artitsAdiLbl.AutoSize = true;
            this.artitsAdiLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.artitsAdiLbl.Location = new System.Drawing.Point(73, 33);
            this.artitsAdiLbl.Name = "artitsAdiLbl";
            this.artitsAdiLbl.Size = new System.Drawing.Size(41, 13);
            this.artitsAdiLbl.TabIndex = 1;
            this.artitsAdiLbl.Text = "label1";
            // 
            // baslikLbl
            // 
            this.baslikLbl.AutoSize = true;
            this.baslikLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.baslikLbl.Location = new System.Drawing.Point(34, 255);
            this.baslikLbl.Name = "baslikLbl";
            this.baslikLbl.Size = new System.Drawing.Size(41, 13);
            this.baslikLbl.TabIndex = 2;
            this.baslikLbl.Text = "label2";
            // 
            // aciklamaLbl
            // 
            this.aciklamaLbl.AutoSize = true;
            this.aciklamaLbl.Location = new System.Drawing.Point(34, 273);
            this.aciklamaLbl.MaximumSize = new System.Drawing.Size(250, 0);
            this.aciklamaLbl.Name = "aciklamaLbl";
            this.aciklamaLbl.Size = new System.Drawing.Size(35, 13);
            this.aciklamaLbl.TabIndex = 3;
            this.aciklamaLbl.Text = "label3";
            // 
            // yorumlarFLP
            // 
            this.yorumlarFLP.AutoScroll = true;
            this.yorumlarFLP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yorumlarFLP.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.yorumlarFLP.Location = new System.Drawing.Point(314, 61);
            this.yorumlarFLP.Name = "yorumlarFLP";
            this.yorumlarFLP.Size = new System.Drawing.Size(347, 191);
            this.yorumlarFLP.TabIndex = 4;
            this.yorumlarFLP.WrapContents = false;
            // 
            // begenBtn
            // 
            this.begenBtn.BackColor = System.Drawing.SystemColors.Control;
            this.begenBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.begenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.begenBtn.Location = new System.Drawing.Point(53, 320);
            this.begenBtn.Name = "begenBtn";
            this.begenBtn.Size = new System.Drawing.Size(67, 34);
            this.begenBtn.TabIndex = 5;
            this.begenBtn.UseVisualStyleBackColor = false;
            this.begenBtn.Click += new System.EventHandler(this.begenBtn_Click);
            // 
            // favoriBtn
            // 
            this.favoriBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.favoriBtn.Location = new System.Drawing.Point(149, 320);
            this.favoriBtn.Name = "favoriBtn";
            this.favoriBtn.Size = new System.Drawing.Size(67, 34);
            this.favoriBtn.TabIndex = 6;
            this.favoriBtn.UseVisualStyleBackColor = true;
            this.favoriBtn.Click += new System.EventHandler(this.favoriBtn_Click);
            // 
            // yorumTxtBox
            // 
            this.yorumTxtBox.Location = new System.Drawing.Point(314, 258);
            this.yorumTxtBox.Multiline = true;
            this.yorumTxtBox.Name = "yorumTxtBox";
            this.yorumTxtBox.Size = new System.Drawing.Size(275, 34);
            this.yorumTxtBox.TabIndex = 7;
            // 
            // gonderBtn
            // 
            this.gonderBtn.Location = new System.Drawing.Point(595, 258);
            this.gonderBtn.Name = "gonderBtn";
            this.gonderBtn.Size = new System.Drawing.Size(66, 34);
            this.gonderBtn.TabIndex = 8;
            this.gonderBtn.Text = "Gönder";
            this.gonderBtn.UseVisualStyleBackColor = true;
            this.gonderBtn.Click += new System.EventHandler(this.gonderBtn_Click);
            // 
            // begeniSayiLbl
            // 
            this.begeniSayiLbl.AutoSize = true;
            this.begeniSayiLbl.Location = new System.Drawing.Point(34, 331);
            this.begeniSayiLbl.Name = "begeniSayiLbl";
            this.begeniSayiLbl.Size = new System.Drawing.Size(13, 13);
            this.begeniSayiLbl.TabIndex = 9;
            this.begeniSayiLbl.Text = "0";
            // 
            // favoriSayiLbl
            // 
            this.favoriSayiLbl.AutoSize = true;
            this.favoriSayiLbl.Location = new System.Drawing.Point(130, 331);
            this.favoriSayiLbl.Name = "favoriSayiLbl";
            this.favoriSayiLbl.Size = new System.Drawing.Size(13, 13);
            this.favoriSayiLbl.TabIndex = 10;
            this.favoriSayiLbl.Text = "0";
            // 
            // gonderiProfilPictureBox
            // 
            this.gonderiProfilPictureBox.Location = new System.Drawing.Point(37, 25);
            this.gonderiProfilPictureBox.Name = "gonderiProfilPictureBox";
            this.gonderiProfilPictureBox.Size = new System.Drawing.Size(30, 30);
            this.gonderiProfilPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gonderiProfilPictureBox.TabIndex = 11;
            this.gonderiProfilPictureBox.TabStop = false;
            // 
            // uploadDateLbl
            // 
            this.uploadDateLbl.AutoSize = true;
            this.uploadDateLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.uploadDateLbl.Location = new System.Drawing.Point(220, 33);
            this.uploadDateLbl.MaximumSize = new System.Drawing.Size(250, 0);
            this.uploadDateLbl.Name = "uploadDateLbl";
            this.uploadDateLbl.Size = new System.Drawing.Size(35, 13);
            this.uploadDateLbl.TabIndex = 12;
            this.uploadDateLbl.Text = "label3";
            this.uploadDateLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gonderiSilBtn
            // 
            this.gonderiSilBtn.BackColor = System.Drawing.Color.Maroon;
            this.gonderiSilBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gonderiSilBtn.ForeColor = System.Drawing.Color.White;
            this.gonderiSilBtn.Location = new System.Drawing.Point(568, 25);
            this.gonderiSilBtn.Name = "gonderiSilBtn";
            this.gonderiSilBtn.Size = new System.Drawing.Size(93, 30);
            this.gonderiSilBtn.TabIndex = 13;
            this.gonderiSilBtn.Text = "Gönderiyi Sil";
            this.gonderiSilBtn.UseVisualStyleBackColor = false;
            this.gonderiSilBtn.Click += new System.EventHandler(this.gonderiSilBtn_Click);
            // 
            // GonderiCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.gonderiSilBtn);
            this.Controls.Add(this.uploadDateLbl);
            this.Controls.Add(this.gonderiProfilPictureBox);
            this.Controls.Add(this.favoriSayiLbl);
            this.Controls.Add(this.begeniSayiLbl);
            this.Controls.Add(this.gonderBtn);
            this.Controls.Add(this.yorumTxtBox);
            this.Controls.Add(this.favoriBtn);
            this.Controls.Add(this.begenBtn);
            this.Controls.Add(this.yorumlarFLP);
            this.Controls.Add(this.aciklamaLbl);
            this.Controls.Add(this.baslikLbl);
            this.Controls.Add(this.artitsAdiLbl);
            this.Controls.Add(this.pictureBoxFoto);
            this.Name = "GonderiCard";
            this.Size = new System.Drawing.Size(702, 380);
            this.Load += new System.EventHandler(this.GonderiCard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFoto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gonderiProfilPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxFoto;
        private System.Windows.Forms.Label artitsAdiLbl;
        private System.Windows.Forms.Label baslikLbl;
        private System.Windows.Forms.Label aciklamaLbl;
        private System.Windows.Forms.FlowLayoutPanel yorumlarFLP;
        private System.Windows.Forms.Button begenBtn;
        private System.Windows.Forms.Button favoriBtn;
        private System.Windows.Forms.TextBox yorumTxtBox;
        private System.Windows.Forms.Button gonderBtn;
        private System.Windows.Forms.Label begeniSayiLbl;
        private System.Windows.Forms.Label favoriSayiLbl;
        private System.Windows.Forms.PictureBox gonderiProfilPictureBox;
        private System.Windows.Forms.Label uploadDateLbl;
        private System.Windows.Forms.Button gonderiSilBtn;
    }
}
