﻿namespace DijitalSanatGalerisi
{
    partial class Gonderilerim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanelGonderilerim = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.kategoriMyCmbBox = new System.Windows.Forms.ComboBox();
            this.filtreleMyBtn = new System.Windows.Forms.Button();
            this.BtnMySirala = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMyLikeSayisi = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(718, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 35);
            this.button3.TabIndex = 11;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(677, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 35);
            this.button1.TabIndex = 22;
            this.button1.Text = "<";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 24);
            this.label1.TabIndex = 23;
            this.label1.Text = "Gönderilerim";
            // 
            // flowLayoutPanelGonderilerim
            // 
            this.flowLayoutPanelGonderilerim.AutoScroll = true;
            this.flowLayoutPanelGonderilerim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanelGonderilerim.Location = new System.Drawing.Point(16, 65);
            this.flowLayoutPanelGonderilerim.Name = "flowLayoutPanelGonderilerim";
            this.flowLayoutPanelGonderilerim.Size = new System.Drawing.Size(737, 455);
            this.flowLayoutPanelGonderilerim.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "Kategori";
            // 
            // kategoriMyCmbBox
            // 
            this.kategoriMyCmbBox.FormattingEnabled = true;
            this.kategoriMyCmbBox.Items.AddRange(new object[] {
            "Tarih",
            "Manzara",
            "Bilgi",
            "Eğlence"});
            this.kategoriMyCmbBox.Location = new System.Drawing.Point(149, 28);
            this.kategoriMyCmbBox.Name = "kategoriMyCmbBox";
            this.kategoriMyCmbBox.Size = new System.Drawing.Size(121, 21);
            this.kategoriMyCmbBox.TabIndex = 25;
            // 
            // filtreleMyBtn
            // 
            this.filtreleMyBtn.Location = new System.Drawing.Point(276, 28);
            this.filtreleMyBtn.Name = "filtreleMyBtn";
            this.filtreleMyBtn.Size = new System.Drawing.Size(75, 21);
            this.filtreleMyBtn.TabIndex = 27;
            this.filtreleMyBtn.Text = "Filtrele";
            this.filtreleMyBtn.UseVisualStyleBackColor = true;
            this.filtreleMyBtn.Click += new System.EventHandler(this.filtreleMyBtn_Click);
            // 
            // BtnMySirala
            // 
            this.BtnMySirala.Location = new System.Drawing.Point(477, 29);
            this.BtnMySirala.Name = "BtnMySirala";
            this.BtnMySirala.Size = new System.Drawing.Size(75, 21);
            this.BtnMySirala.TabIndex = 21;
            this.BtnMySirala.Text = "Sırala";
            this.BtnMySirala.UseVisualStyleBackColor = true;
            this.BtnMySirala.Click += new System.EventHandler(this.BtnMySirala_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(368, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Beğeni Sayısı";
            // 
            // txtMyLikeSayisi
            // 
            this.txtMyLikeSayisi.Location = new System.Drawing.Point(371, 29);
            this.txtMyLikeSayisi.Name = "txtMyLikeSayisi";
            this.txtMyLikeSayisi.Size = new System.Drawing.Size(100, 20);
            this.txtMyLikeSayisi.TabIndex = 19;
            // 
            // Gonderilerim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 532);
            this.Controls.Add(this.BtnMySirala);
            this.Controls.Add(this.filtreleMyBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMyLikeSayisi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.kategoriMyCmbBox);
            this.Controls.Add(this.flowLayoutPanelGonderilerim);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Gonderilerim";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gonderilerim";
            this.Load += new System.EventHandler(this.Gonderilerim_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelGonderilerim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox kategoriMyCmbBox;
        private System.Windows.Forms.Button filtreleMyBtn;
        private System.Windows.Forms.Button BtnMySirala;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMyLikeSayisi;
    }
}