﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DijitalSanatGalerisi
{
    public static class kullaniciBilgileri
    {
        public static int artist_id { get; set; }
        public static string fname { get; set; }
        public static string lname { get; set; }
        public static string email { get; set; }
        public static string username { get; set; }
        public static string password { get; set; }
        public static string profile_image { get; set; }
    }
}
