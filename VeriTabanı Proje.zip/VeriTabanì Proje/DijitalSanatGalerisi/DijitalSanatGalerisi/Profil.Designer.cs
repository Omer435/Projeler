﻿namespace DijitalSanatGalerisi
{
    partial class Profil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtProfilAd = new System.Windows.Forms.TextBox();
            this.txtProfilSoyad = new System.Windows.Forms.TextBox();
            this.txtProfilKullaniciAdi = new System.Windows.Forms.TextBox();
            this.txtProfilEposta = new System.Windows.Forms.TextBox();
            this.picProfile = new System.Windows.Forms.PictureBox();
            this.btnFotoYukle = new System.Windows.Forms.Button();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.btnDuzenle = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.logOutBtn = new System.Windows.Forms.Button();
            this.gonderilerimBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picProfile)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(279, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "PROFİL BİLGİLERİ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(117, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Soyad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Kullanıcı Adı:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(110, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "E-Posta:";
            // 
            // txtProfilAd
            // 
            this.txtProfilAd.Location = new System.Drawing.Point(177, 120);
            this.txtProfilAd.Name = "txtProfilAd";
            this.txtProfilAd.ReadOnly = true;
            this.txtProfilAd.Size = new System.Drawing.Size(139, 20);
            this.txtProfilAd.TabIndex = 5;
            // 
            // txtProfilSoyad
            // 
            this.txtProfilSoyad.Location = new System.Drawing.Point(177, 154);
            this.txtProfilSoyad.Name = "txtProfilSoyad";
            this.txtProfilSoyad.ReadOnly = true;
            this.txtProfilSoyad.Size = new System.Drawing.Size(139, 20);
            this.txtProfilSoyad.TabIndex = 6;
            // 
            // txtProfilKullaniciAdi
            // 
            this.txtProfilKullaniciAdi.Location = new System.Drawing.Point(177, 182);
            this.txtProfilKullaniciAdi.Name = "txtProfilKullaniciAdi";
            this.txtProfilKullaniciAdi.ReadOnly = true;
            this.txtProfilKullaniciAdi.Size = new System.Drawing.Size(139, 20);
            this.txtProfilKullaniciAdi.TabIndex = 7;
            // 
            // txtProfilEposta
            // 
            this.txtProfilEposta.Location = new System.Drawing.Point(177, 211);
            this.txtProfilEposta.Name = "txtProfilEposta";
            this.txtProfilEposta.ReadOnly = true;
            this.txtProfilEposta.Size = new System.Drawing.Size(139, 20);
            this.txtProfilEposta.TabIndex = 8;
            // 
            // picProfile
            // 
            this.picProfile.Location = new System.Drawing.Point(489, 120);
            this.picProfile.Name = "picProfile";
            this.picProfile.Size = new System.Drawing.Size(150, 150);
            this.picProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picProfile.TabIndex = 9;
            this.picProfile.TabStop = false;
            // 
            // btnFotoYukle
            // 
            this.btnFotoYukle.Location = new System.Drawing.Point(514, 276);
            this.btnFotoYukle.Name = "btnFotoYukle";
            this.btnFotoYukle.Size = new System.Drawing.Size(100, 23);
            this.btnFotoYukle.TabIndex = 10;
            this.btnFotoYukle.Text = "Fotoğraf Yükle";
            this.btnFotoYukle.UseVisualStyleBackColor = true;
            this.btnFotoYukle.Click += new System.EventHandler(this.btnFotoYukle_Click);
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Enabled = false;
            this.btnGuncelle.Location = new System.Drawing.Point(241, 276);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnGuncelle.TabIndex = 11;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            this.btnGuncelle.Click += new System.EventHandler(this.btnGuncelle_Click);
            // 
            // btnDuzenle
            // 
            this.btnDuzenle.Location = new System.Drawing.Point(160, 276);
            this.btnDuzenle.Name = "btnDuzenle";
            this.btnDuzenle.Size = new System.Drawing.Size(75, 23);
            this.btnDuzenle.TabIndex = 12;
            this.btnDuzenle.Text = "Düzenle";
            this.btnDuzenle.UseVisualStyleBackColor = true;
            this.btnDuzenle.Click += new System.EventHandler(this.btnDuzenle_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(718, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 35);
            this.button3.TabIndex = 13;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(677, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 35);
            this.button1.TabIndex = 14;
            this.button1.Text = "<";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // logOutBtn
            // 
            this.logOutBtn.Location = new System.Drawing.Point(561, 402);
            this.logOutBtn.Name = "logOutBtn";
            this.logOutBtn.Size = new System.Drawing.Size(78, 30);
            this.logOutBtn.TabIndex = 15;
            this.logOutBtn.Text = "Çıkış Yap";
            this.logOutBtn.UseVisualStyleBackColor = true;
            this.logOutBtn.Click += new System.EventHandler(this.logOutBtn_Click);
            // 
            // gonderilerimBtn
            // 
            this.gonderilerimBtn.Location = new System.Drawing.Point(477, 402);
            this.gonderilerimBtn.Name = "gonderilerimBtn";
            this.gonderilerimBtn.Size = new System.Drawing.Size(78, 30);
            this.gonderilerimBtn.TabIndex = 16;
            this.gonderilerimBtn.Text = "Gönderilerim";
            this.gonderilerimBtn.UseVisualStyleBackColor = true;
            this.gonderilerimBtn.Click += new System.EventHandler(this.gonderilerimBtn_Click);
            // 
            // Profil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 532);
            this.Controls.Add(this.gonderilerimBtn);
            this.Controls.Add(this.logOutBtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnDuzenle);
            this.Controls.Add(this.btnGuncelle);
            this.Controls.Add(this.btnFotoYukle);
            this.Controls.Add(this.picProfile);
            this.Controls.Add(this.txtProfilEposta);
            this.Controls.Add(this.txtProfilKullaniciAdi);
            this.Controls.Add(this.txtProfilSoyad);
            this.Controls.Add(this.txtProfilAd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Profil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Profil";
            this.Load += new System.EventHandler(this.Profil_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picProfile)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtProfilAd;
        private System.Windows.Forms.TextBox txtProfilSoyad;
        private System.Windows.Forms.TextBox txtProfilKullaniciAdi;
        private System.Windows.Forms.TextBox txtProfilEposta;
        private System.Windows.Forms.PictureBox picProfile;
        private System.Windows.Forms.Button btnFotoYukle;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.Button btnDuzenle;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button logOutBtn;
        private System.Windows.Forms.Button gonderilerimBtn;
    }
}