﻿namespace DijitalSanatGalerisi
{
    partial class AnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowGallery = new System.Windows.Forms.FlowLayoutPanel();
            this.profilBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.kategoriCmbBox = new System.Windows.Forms.ComboBox();
            this.filtreleBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.sanatciTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gndrYukleBtn = new System.Windows.Forms.Button();
            this.txtLikeSayisi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnSirala = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // flowGallery
            // 
            this.flowGallery.AutoScroll = true;
            this.flowGallery.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowGallery.Location = new System.Drawing.Point(12, 52);
            this.flowGallery.Name = "flowGallery";
            this.flowGallery.Size = new System.Drawing.Size(741, 468);
            this.flowGallery.TabIndex = 0;
            // 
            // profilBtn
            // 
            this.profilBtn.Location = new System.Drawing.Point(635, 11);
            this.profilBtn.Name = "profilBtn";
            this.profilBtn.Size = new System.Drawing.Size(77, 35);
            this.profilBtn.TabIndex = 1;
            this.profilBtn.Text = "Profilim";
            this.profilBtn.UseVisualStyleBackColor = true;
            this.profilBtn.Click += new System.EventHandler(this.profilBtn_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(718, 11);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 35);
            this.button3.TabIndex = 9;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // kategoriCmbBox
            // 
            this.kategoriCmbBox.FormattingEnabled = true;
            this.kategoriCmbBox.Items.AddRange(new object[] {
            "Tarih",
            "Manzara",
            "Bilgi",
            "Eğlence"});
            this.kategoriCmbBox.Location = new System.Drawing.Point(12, 25);
            this.kategoriCmbBox.Name = "kategoriCmbBox";
            this.kategoriCmbBox.Size = new System.Drawing.Size(121, 21);
            this.kategoriCmbBox.TabIndex = 10;
            // 
            // filtreleBtn
            // 
            this.filtreleBtn.Location = new System.Drawing.Point(245, 24);
            this.filtreleBtn.Name = "filtreleBtn";
            this.filtreleBtn.Size = new System.Drawing.Size(75, 21);
            this.filtreleBtn.TabIndex = 11;
            this.filtreleBtn.Text = "Filtrele";
            this.filtreleBtn.UseVisualStyleBackColor = true;
            this.filtreleBtn.Click += new System.EventHandler(this.filtreleBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Kategori";
            // 
            // sanatciTxt
            // 
            this.sanatciTxt.Location = new System.Drawing.Point(139, 25);
            this.sanatciTxt.Name = "sanatciTxt";
            this.sanatciTxt.Size = new System.Drawing.Size(100, 20);
            this.sanatciTxt.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(136, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Sanatçı";
            // 
            // gndrYukleBtn
            // 
            this.gndrYukleBtn.Location = new System.Drawing.Point(552, 10);
            this.gndrYukleBtn.Name = "gndrYukleBtn";
            this.gndrYukleBtn.Size = new System.Drawing.Size(77, 35);
            this.gndrYukleBtn.TabIndex = 15;
            this.gndrYukleBtn.Text = "Yükle";
            this.gndrYukleBtn.UseVisualStyleBackColor = true;
            this.gndrYukleBtn.Click += new System.EventHandler(this.gndrYukleBtn_Click);
            // 
            // txtLikeSayisi
            // 
            this.txtLikeSayisi.Location = new System.Drawing.Point(345, 26);
            this.txtLikeSayisi.Name = "txtLikeSayisi";
            this.txtLikeSayisi.Size = new System.Drawing.Size(100, 20);
            this.txtLikeSayisi.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(342, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Beğeni Sayısı";
            // 
            // BtnSirala
            // 
            this.BtnSirala.Location = new System.Drawing.Point(451, 26);
            this.BtnSirala.Name = "BtnSirala";
            this.BtnSirala.Size = new System.Drawing.Size(75, 21);
            this.BtnSirala.TabIndex = 18;
            this.BtnSirala.Text = "Sırala";
            this.BtnSirala.UseVisualStyleBackColor = true;
            this.BtnSirala.Click += new System.EventHandler(this.BtnSirala_Click);
            // 
            // AnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 532);
            this.Controls.Add(this.BtnSirala);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtLikeSayisi);
            this.Controls.Add(this.gndrYukleBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sanatciTxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filtreleBtn);
            this.Controls.Add(this.kategoriCmbBox);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.profilBtn);
            this.Controls.Add(this.flowGallery);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AnaSayfa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ana Sayfa";
            this.Load += new System.EventHandler(this.AnaSayfa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowGallery;
        private System.Windows.Forms.Button profilBtn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox kategoriCmbBox;
        private System.Windows.Forms.Button filtreleBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox sanatciTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button gndrYukleBtn;
        private System.Windows.Forms.TextBox txtLikeSayisi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnSirala;
    }
}