﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DijitalSanatGalerisi
{
    public partial class kayitEkrani : Form
    {
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=digitalGallery; user ID=postgres; password=1234");
        public kayitEkrani()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            girisEkrani giris = new girisEkrani();
            this.Close();
            giris.Show();
                   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (registerMailTxt.Text.Length > 5 && registerUsernameTxt.Text.Length > 5 && registerPasswordTxt.Text.Length > 5 && registerAdTxt.Text.Length >= 3 && registerSoyadTxt.Text.Length >= 2)
                {
                    if (kosullarCheckBox.Checked)
                    {
                        baglanti.Open();
                        NpgsqlCommand kayit = new NpgsqlCommand("insert into artist (fname,lname,email,username,password) values (@p1,@p2,@p3,@p4,@p5)",baglanti);
                        kayit.Parameters.AddWithValue("@p1",registerAdTxt.Text);
                        kayit.Parameters.AddWithValue("@p2", registerSoyadTxt.Text);
                        kayit.Parameters.AddWithValue("@p3", registerMailTxt.Text);
                        kayit.Parameters.AddWithValue("@p4", registerUsernameTxt.Text);
                        kayit.Parameters.AddWithValue("@p5", registerPasswordTxt.Text);
                        kayit.ExecuteNonQuery();
                        baglanti.Close();
                        MessageBox.Show("Başarıyla Kayıt Olundu!");
                        girisEkrani giris = new girisEkrani();
                        this.Close();
                        giris.Show();
                    }
                    else
                    {
                        MessageBox.Show("Koşulları Kabul Etmelisiniz.");
                    }
                }
                else
                {
                    MessageBox.Show("Uygunsuz Değerler");
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Bir şeyler yanlış!");
            }
            baglanti.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
