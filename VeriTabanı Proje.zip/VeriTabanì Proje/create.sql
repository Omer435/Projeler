-- ARTIST tablosu (USER’dan specialization; silme kısıtı: ON DELETE RESTRICT)
CREATE TABLE artist (
  artist_id SERIAL PRIMARY KEY,
  fname           TEXT    NOT NULL,
  lname           TEXT    NOT NULL,
  email          TEXT    NOT NULL UNIQUE,
  username       TEXT    NOT NULL UNIQUE,
  password       TEXT    NOT NULL,
  profile_image TEXT DEFAULT './uploads/profiles/default-image.jpg'
);

-- ARTWORK tablosu
CREATE TABLE artwork (
  artwork_id   SERIAL PRIMARY KEY,
  title        TEXT      NOT NULL,
  description  TEXT,
  image_path TEXT NOT NULL,
  upload_date  TIMESTAMPTZ NOT NULL DEFAULT now(),
  category TEXT CHECK (category IN ('Tarih', 'Bilgi', 'Manzara', 'Eğlence')),
  artist_id    INTEGER   NOT NULL
    REFERENCES artist(artist_id) ON DELETE CASCADE
);

-- COMMENTS tablosu
CREATE TABLE comments (
    commentid SERIAL PRIMARY KEY,
    artworkid INT REFERENCES artwork(artwork_id) ON DELETE CASCADE,
    artistid INT REFERENCES artist(artist_id),
    content TEXT,
    createdat TIMESTAMP DEFAULT now()
);


-- LIKES tablosu
CREATE TABLE likes (
    likeid SERIAL PRIMARY KEY,
    artworkid INT REFERENCES artwork(artwork_id) ON DELETE CASCADE,
    artistid INT REFERENCES artist(artist_id),
    createdat TIMESTAMP DEFAULT now(),
    UNIQUE (artworkid, artistid)
);


-- FAVORITES tablosu
CREATE TABLE favorites (
    favoriteid SERIAL PRIMARY KEY,
    artworkid INT REFERENCES artwork(artwork_id) ON DELETE CASCADE,
    artistid INT REFERENCES artist(artist_id),
    createdat TIMESTAMP DEFAULT now(),
    UNIQUE (artworkid, artistid)
);


-- ARTIST_LOG tablosu

CREATE TABLE artist_log (
    log_id SERIAL PRIMARY KEY,
    artist_id INT,
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- LIKE_LOG tablosu

CREATE TABLE like_log (
    log_id SERIAL PRIMARY KEY,
    artwork_id INT NOT NULL,
    artistid INT NOT NULL,
    liked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


--VIEW
create or replace view get_artwork_id as select artwork_id from artwork order by upload_date desc;


-- FUNCTION

CREATE OR REPLACE FUNCTION get_filtered_likes_artworks(min_likes INT)
RETURNS TABLE (artwork_id INT, title TEXT, like_count INT)
AS $$
    SELECT a.artwork_id, a.title, COUNT(l.likeid) AS like_count
    FROM artwork a
    JOIN likes l ON a.artwork_id = l.artworkid
    GROUP BY a.artwork_id, a.title
    HAVING COUNT(l.likeid) > $1;
$$ LANGUAGE sql;


CREATE OR REPLACE FUNCTION log_new_artist()
RETURNS TRIGGER AS
$$
BEGIN
    INSERT INTO artist_log (artist_id)
    VALUES (NEW.artist_id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION log_like_insert()
RETURNS TRIGGER AS
$$
BEGIN
    INSERT INTO like_log (artwork_id, artistid)
    VALUES (NEW.artworkid, NEW.artistid);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION get_my_artworks_by_category(artistid_ INT,category_ TEXT)
RETURNS TABLE (
    artwork_id INT,
    title TEXT,
    description TEXT,
    image_path TEXT,
    upload_date TIMESTAMPTZ
)
LANGUAGE sql
AS $$
    SELECT artwork_id, title, description, image_path, upload_date
    FROM artwork
    WHERE artist_id = artistid_
      AND (LOWER(category) = LOWER(category_));
$$;


CREATE OR REPLACE FUNCTION get_my_artworks_by_min_likes(_artist_id INT,_min_likes INT)
RETURNS TABLE (
    artwork_id INT,
    title TEXT,
    description TEXT,
    image_path TEXT,
    upload_date TIMESTAMPTZ,
    like_count BIGINT
)
LANGUAGE plpgsql
AS $$
DECLARE
    rec RECORD;
    cur CURSOR FOR
        SELECT a.artwork_id, a.title, a.description, a.image_path, a.upload_date,
               COUNT(l.likeid) AS like_count
        FROM artwork a
        LEFT JOIN likes l ON a.artwork_id = l.artworkid
        WHERE a.artist_id = _artist_id
        GROUP BY a.artwork_id, a.title, a.description, a.image_path, a.upload_date
        HAVING COUNT(l.likeid) > _min_likes;
BEGIN
    FOR rec IN cur LOOP
        artwork_id := rec.artwork_id;
        title := rec.title;
        description := rec.description;
        image_path := rec.image_path;
        upload_date := rec.upload_date;
        like_count := rec.like_count;
        RETURN NEXT;
    END LOOP;
    RETURN;
END;
$$;

-- TRIGGER

CREATE TRIGGER trg_log_new_artist
AFTER INSERT ON artist
FOR EACH ROW
EXECUTE FUNCTION log_new_artist();


CREATE TRIGGER trg_log_like_insert
AFTER INSERT ON likes
FOR EACH ROW
EXECUTE FUNCTION log_like_insert();
