--ARTIST TABLOSU

insert into artist (fname,lname,email,username,password) values ('Ömer','Özçelik','omerozcelik@gmail.com','omerozcelik','123456');
insert into artist (fname,lname,email,username,password) values ('Baran','Yılmaz','baranyilmaz@gmail.com','ylmzbaran','654321');
insert into artist (fname,lname,email,username,password) values ('Ali','Kaya','alikaya@gmail.com','alikaya','123456');
insert into artist (fname,lname,email,username,password) values ('Ahmet','Uzun','ahmetuzun@gmail.com','ahmetuzun','123456');
insert into artist (fname,lname,email,username,password) values ('Mehmet','Demir','mehmetdemir@gmail.com','mehmetdemir','345678');
insert into artist (fname,lname,email,username,password) values ('Veysel','Akar','veyselakar@gmail.com','veyselakar','123456');
insert into artist (fname,lname,email,username,password) values ('Murat','Çoban','muratcoban@gmail.com','muratcoban','123456');
insert into artist (fname,lname,email,username,password) values ('Hüsnü','Atan','husnuatan@gmail.com','husnuatan','123456');
insert into artist (fname,lname,email,username,password) values ('Rıza','Bektaş','rizabektas@gmail.com','rizabektas','123456');
insert into artist (fname,lname,email,username,password) values ('Selin','Biçer','selinbicer@gmail.com','selinbicer','123456');


--ARTWORK TABLOSU

insert into artwork (title,description,artist_id,image_path,category) values ('Eyfel Kulesi','Eyfel Kulesi, Pariste bulunan demir kule. Kule, aynı zamanda tüm dünyada Fransa sembolü halini almıştır.',1,'./uploads/eyfel.jpg','Tarih');
insert into artwork (title,description,artist_id,image_path,category) values ('Galata Kulesi','Galata Kulesi ya da müze olarak kullanılmaya başlaması sonrasındaki adıyla Galata Kulesi Müzesi',2,'./uploads/galata-kulesi.jpg','Tarih');
insert into artwork (title,description,artist_id,image_path,category) values ('Boğaz','İstanbul Boğazı',3,'./uploads/istanbul-bogaz.jpg','Manzara');
insert into artwork (title,description,artist_id,image_path,category) values ('Yıldızlı Gece','Vincent Van Gogh, “The Starry Night” (Yıldızlı Gece); 1889',4,'./uploads/yildizli-gece.jpg','Bilgi');
insert into artwork (title,description,artist_id,image_path,category) values ('The Kiss','Gustav Klimt, “The Kiss” (Öpücük); 1907',5,'./uploads/the-kiss.jpg','Bilgi');
insert into artwork (title,description,artist_id,image_path,category) values ('İnci Küpeli Kız','"Hollandalı Mona Lisa" olarak da bilinen bu tablo Lahey''de bulunan Mauritshuis''te sergilenmektedir.',6,'./uploads/inci-kupeli.jpg','Bilgi');
insert into artwork (title,description,artist_id,image_path,category) values ('Vialand','Vialand ya da eski adıyla İsfanbul, Türkiye''de inşa edilmiş ilk tema parktır.',7,'./uploads/vialand.jpg','Eğlence');
insert into artwork (title,description,artist_id,image_path,category) values ('Van Kedisi','Gözleri mavi veya yeşil rengi ya da biri mavi diğeri yeşil olabilen bir kedi ırkı.',8,'./uploads/van-kedisi.jpg','Bilgi');
insert into artwork (title,description,artist_id,image_path,category) values ('Marina Aquapark','Tuzla’da konumlanan Marina Aquapark Waterland, şehrin en büyük kapalı su parkı.',9,'./uploads/marina-aqua.jpg','Eğlence');
insert into artwork (title,description,artist_id,image_path,category) values ('Belgrad Ormanı','Belgrad Ormanı, Çatalca Yarımadasında yer alan doğal oluşumlu ağaçlık bölgedir.',10,'./uploads/belgrad-ormani.jpg','Manzara');



--COMMENTS TABLOSU
insert into comments (artworkid,artistid,content) values (1,10,'çok güzel');
insert into comments (artworkid,artistid,content) values (2,9,'güzel manzara');
insert into comments (artworkid,artistid,content) values (3,8,'ünlü bir eser');
insert into comments (artworkid,artistid,content) values (4,7,'daha önce gittim');
insert into comments (artworkid,artistid,content) values (5,6,'ilk defa gördüm');
insert into comments (artworkid,artistid,content) values (6,5,'hollandalı mona lisa');
insert into comments (artworkid,artistid,content) values (7,4,'çok eğlendim');
insert into comments (artworkid,artistid,content) values (8,3,'bu kedi çok tatlı');
insert into comments (artworkid,artistid,content) values (9,2,'yazın gidilir');
insert into comments (artworkid,artistid,content) values (10,1,'doğayı sevenler için');



--LIKES TABLOSU
insert into likes (artworkid,artistid) values (1,10);
insert into likes (artworkid,artistid) values (2,9);
insert into likes (artworkid,artistid) values (3,8);
insert into likes (artworkid,artistid) values (4,7);
insert into likes (artworkid,artistid) values (5,6);
insert into likes (artworkid,artistid) values (6,5);
insert into likes (artworkid,artistid) values (7,4);
insert into likes (artworkid,artistid) values (8,3);
insert into likes (artworkid,artistid) values (9,2);
insert into likes (artworkid,artistid) values (10,1);



--FAVORITES TABLOSU
insert into favorites (artworkid,artistid) values (1,10);
insert into favorites (artworkid,artistid) values (2,9);
insert into favorites (artworkid,artistid) values (3,8);
insert into favorites (artworkid,artistid) values (4,7);
insert into favorites (artworkid,artistid) values (5,6);
insert into favorites (artworkid,artistid) values (6,5);
insert into favorites (artworkid,artistid) values (7,4);
insert into favorites (artworkid,artistid) values (8,3);
insert into favorites (artworkid,artistid) values (9,2);
insert into favorites (artworkid,artistid) values (10,1);


--ARTIST_LOG TABLOSU
insert into artist_log (artist_id) values (1);
insert into artist_log (artist_id) values (2);
insert into artist_log (artist_id) values (3);
insert into artist_log (artist_id) values (4);
insert into artist_log (artist_id) values (5);
insert into artist_log (artist_id) values (6);
insert into artist_log (artist_id) values (7);
insert into artist_log (artist_id) values (8);
insert into artist_log (artist_id) values (9);
insert into artist_log (artist_id) values (10);


--LIKE_LOG TABLOSU
insert into like_log (artwork_id,artistid) values (1,10);
insert into like_log (artwork_id,artistid) values (2,9);
insert into like_log (artwork_id,artistid) values (3,8);
insert into like_log (artwork_id,artistid) values (4,7);
insert into like_log (artwork_id,artistid) values (5,6);
insert into like_log (artwork_id,artistid) values (6,5);
insert into like_log (artwork_id,artistid) values (7,4);
insert into like_log (artwork_id,artistid) values (8,3);
insert into like_log (artwork_id,artistid) values (9,2);
insert into like_log (artwork_id,artistid) values (10,1);
 